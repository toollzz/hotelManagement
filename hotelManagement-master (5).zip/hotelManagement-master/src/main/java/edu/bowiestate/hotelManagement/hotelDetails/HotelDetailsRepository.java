package edu.bowiestate.hotelManagement.hotelDetails;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HotelDetailsRepository extends JpaRepository<HotelDetails, Long> {
}
