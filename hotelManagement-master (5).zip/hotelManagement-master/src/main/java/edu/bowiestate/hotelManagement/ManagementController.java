package edu.bowiestate.hotelManagement;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ManagementController {


    // update days of operation
    // update hours of operation
    // update single room price
    // update double room price
    // update suite room price
    // run reports of everything in the database

    /**
     * View Hotel Details like Days of Operation, Hours of Operation, and prices
     * @param model
     * @return
     */
//    @GetMapping("/hotelDetails")
//    public String getHotelDetails(Model model){
//
//    }
//
//    @PostMapping("/daysOfOperation")
//    public HotelDetails updateDaysOfOperation(){
//
//    }



}
