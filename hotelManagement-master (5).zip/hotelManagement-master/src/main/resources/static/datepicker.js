$('.datepicker').datepicker({
    startDate: new Date(date.getFullYear(), date.getMonth(), date.getDate()),
    endDate: '+14d'
});